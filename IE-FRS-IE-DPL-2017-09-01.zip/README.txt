IE FRC and IE DPL Taxonomy version 1.0.0
Formal version date: 2017-09-01
Release date: 2017-08-28

Taxonomy package contents:
* IE-FRS-IE-DPL V1.0.0/
  * README.txt - this document
  * META-INF/taxonomyPackage.xml - Taxonomy package metadata, including entry points
  * META-INF/catalog.xml - OASIS remappings catalog

  * www.revenue.ie/schemas/ct - IE FRC and DPL extension taxonomies root directory
    - IE-DPL/2017-09-01 - IE-DPL taxonomy;
    - combined/2017-09-01 - Combined IE FRC extension taxonomy and IE-DPL taxonomy entry points

  * doc/
    - IE-FRS-IE-DPL-2017-09-01.xls - Details of the combined entry points
    - IE-FRS-IE-DPL-Release Notes.pdf

  * instances/
    * ie-dpl.xbrl - An XBRL instance for taxonomy validation only, includes at least one fact for each item within the IE-DPL taxonomy
    * ie-dpl.html - An inline XBRL instance for taxonomy validation only, includes at least one fact for each item within the IE-DPL taxonomy

